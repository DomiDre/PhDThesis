#!/bin/bash -i
python -u 'THESIS_sanspolCubeModel.py'
python -u 'THESIS_sanspol.py'
python -u 'THESIS_sanspolSphereModel.py'
python -u 'THESIS_saxssansCubeModel.py'
python -u 'THESIS_saxssans.py'
python -u 'THESIS_saxssansSphereModel.py'
